from django.conf.urls import url,include
from django.conf import settings
from django.conf.urls.static import static
import soeiro.atuacao.views as vswat 


urlpatterns = [
    url(r'',vswat.atua_home,name='inicio'),  
]