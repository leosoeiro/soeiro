from django.contrib import admin
from .models import *
class ProjetoTccAdmin(admin.ModelAdmin):

    list_display = ['titulo', 'slug','area','aceito']
    search_fields = ['titulo', 'slug']
    #prepopulated_fields = {'slug': ('name',)}
    class Meta:
        verbose_name = 'Projeto'
        verbose_name_plural = 'Projetos'
        ordering = ['titulo']
    def __str(self):
    	return self.titulo

class AreaAdmin(admin.ModelAdmin):
	list_display = ['descricao']
	search_fields = ['descricao']
    #prepopulated_fields = {'slug': ('name',)}
	class Meta:
		verbose_name = 'Descricao'
		verbose_name_plural = 'Descricoes'
		ordering = ['descricao']

	def __str__(self):
		return self.descricao

admin.site.register(ProjetoTcc,ProjetoTccAdmin)
admin.site.register(Area,AreaAdmin)