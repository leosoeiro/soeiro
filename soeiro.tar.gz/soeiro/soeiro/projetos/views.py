from django.shortcuts import render
from django.http import HttpResponse
from .models import *

def prj_home(request):
	todos = ProjetoTcc.objects.all()
	context = {'title':'Projetos para TCC','objeto':todos}
	template_name = 'projetos.html'
	return render(request,template_name,context)
