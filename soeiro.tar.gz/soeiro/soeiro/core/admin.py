from django.contrib import admin
from .models import *
class InteresseAdmin(admin.ModelAdmin):

    list_display = ['titulo', 'slug']
    search_fields = ['titulo', 'slug']
    #prepopulated_fields = {'slug': ('name',)}
    class Meta:
        verbose_name = 'Interesse'
        verbose_name_plural = 'Interesses'
        ordering = ['titulo']



admin.site.register(Interesse, InteresseAdmin)