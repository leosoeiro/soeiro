from django.shortcuts import render, get_object_or_404
from django.http import HttpResponse
from .forms import FormIndex
from .models import Interesse
from soeiro.projetos.models import *

def home(request):
	todos = ProjetoTcc.objects.filter(aceito=True).count()

	context = {'title':'Home','prj':ProjetoTcc.objects.filter(aceito=True).count(),'orientandos':02,'alunos':187}
	template_name = 'home.html'
	return render(request,'home.html',context)

def contato(request):
	context = {'title':'Contato'}
	template_name = 'contato.html'
	return render(request,'contato.html',context)

def sobre(request):
	context = {'title':'Sobre'}
	template_name = 'sobre.html'
	return render(request,'sobre.html',context)