from django.shortcuts import render
from .models import *
# Create your views here.
def atua_home(request):
	context = {'title':'Interesses do Autor'}
	template_name = 'autacao.html'
	return render(request,template_name,context)
