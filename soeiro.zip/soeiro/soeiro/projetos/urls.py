from django.conf.urls import url,include
import soeiro.projetos.views as vswprj 

urlpatterns = [
	url(r'^',vswprj.prj_home,name='inicio'),
	
]
