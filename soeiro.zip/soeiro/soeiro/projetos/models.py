from __future__ import unicode_literals

from django.db import models


# Create your models here.
class Area(models.Model):
	descricao = models.CharField('Descricao',max_length=100)
	def get_absolute_url():
		pass

	class Meta:
		verbose_name = 'Area'
		verbose_name_plural = 'Areas'
		ordering = ['descricao']
	def __str__(self):
		return self.descricao

class ProjetoTcc(models.Model):
	titulo = models.CharField('Titulo',max_length=100,)
	slug = models.SlugField('Atalho')
	descricao = models.TextField('Sobre a area',blank=True)
	image = models.ImageField(
			upload_to='projetos/images',verbose_name='Imagem',null=True,blank=True
		)
	area = models.ForeignKey(Area,null=True)
	aceito = models.BooleanField('Disponivel',null=False)
	dono = models.CharField('Aceito por',max_length=100,blank=True,null=True)
	add_at = models.DateTimeField('Adicionado em',auto_now_add=True,null=True)
	aceito_em = models.DateTimeField('Aceito em',null=True)
	@models.permalink
	def get_absolute_url(self):
		return ('projetos:inicio', (),{'slug':self.slug})
	class Meta:
		verbose_name = 'Projeto'
		verbose_name_plural = 'Projetos'
		ordering = ['titulo']
	def __str__(self):
		return self.titulo