from django.conf.urls import url,include
import soeiro.core.views as vsw 

urlpatterns = [
	url(r'',vsw.home,name='home'),
	url(r'contato',vsw.contato,name='contato'),
	url(r'sobre',vsw.sobre,name='sobre')
]
