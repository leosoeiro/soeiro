from __future__ import unicode_literals

from django.db import models

# Create your models here.
class Interesse(models.Model):
	titulo = models.CharField('Titulo',max_length=100,)
	slug = models.SlugField('Atalho')
	descricao = models.TextField('Sobre a area',blank=True)
	image = models.ImageField(
			upload_to='interesses/images',verbose_name='Imagem',null=True,blank=True
		)



